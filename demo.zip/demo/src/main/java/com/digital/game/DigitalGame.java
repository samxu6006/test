package com.digital.game;

public class DigitalGame {

    public static void main(String[] args) throws Exception {

        printDigital();

    }

    private static boolean isDivideTree(int num){
        return num%3 ==0 || String.valueOf(num).contains("3");
    }

    private static boolean isDivideFive(int num){
        return num%5 ==0 || String.valueOf(num).contains("5");
    }

    private static boolean isDivideTreeAndFive(int num){
        return isDivideTree(num) && isDivideFive(num);
    }

    public static String judgeDigital(int i) throws Exception {

        if (i <=0 || i>100){
            throw new Exception("digital is out of range");
        }

        if (isDivideTreeAndFive(i)){
            return "FizzBuzz";
        } else if (isDivideTree(i)){
            return "Fizz";
        } else if (isDivideFive(i)){
            return "Buzz";
        }else {
            return String.valueOf(i);
        }
    }

    public static void printDigital() throws Exception {
        for (int i=1;i<=100;i++){
            System.out.println(judgeDigital(i));
        }
    }
}


