import com.digital.game.DigitalGame;
import com.sun.xml.internal.ws.api.server.AbstractServerAsyncTransport;
import org.junit.Assert;
import org.junit.Test;

public class BaseTest {

    @Test
    public void init() throws Exception {

        Assert.assertEquals(DigitalGame.judgeDigital(2), "2");

        Assert.assertEquals(DigitalGame.judgeDigital(3), "Fizz");

        Assert.assertEquals(DigitalGame.judgeDigital(5), "Buzz");

        Assert.assertEquals(DigitalGame.judgeDigital(15), "FizzBuzz");

        Assert.assertEquals(DigitalGame.judgeDigital(37), "Fizz");

        Assert.assertEquals(DigitalGame.judgeDigital(53), "FizzBuzz");

        Assert.assertEquals(DigitalGame.judgeDigital(59), "Buzz");

        Assert.assertEquals(DigitalGame.judgeDigital(97), "97");

        Assert.assertFalse(DigitalGame.judgeDigital(97).equals("Buzz"));

        Assert.assertTrue(DigitalGame.judgeDigital(98).equals("98"));

    }

}